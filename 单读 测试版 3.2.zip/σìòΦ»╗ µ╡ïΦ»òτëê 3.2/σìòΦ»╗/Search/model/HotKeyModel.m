//
//  HotKeyModel.m
//  单读
//
//  Created by mac on 16/2/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HotKeyModel.h"

@implementation HotKeyModel


@end
