//
//  HotKeyModel.h
//  单读
//
//  Created by mac on 16/2/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "JSONModel.h"

@interface HotKeyModel : JSONModel

@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *color;

@end
