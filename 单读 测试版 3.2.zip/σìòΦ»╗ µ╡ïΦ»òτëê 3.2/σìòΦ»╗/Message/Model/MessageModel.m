//
//  MessageModel.m
//  单读
//
//  Created by mac on 16/2/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel

@end
