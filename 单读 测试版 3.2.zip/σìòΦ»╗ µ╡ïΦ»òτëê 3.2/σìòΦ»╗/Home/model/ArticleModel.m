//
//  ArticleModel.m
//  单读
//
//  Created by mac on 16/2/5.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ArticleModel.h"

@implementation ArticleModel

@end
