//
//  MyRefreshHeader.h
//  单读
//
//  Created by mac on 16/2/11.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MJRefreshHeader.h"

@interface MyRefreshHeader : MJRefreshHeader

@end
