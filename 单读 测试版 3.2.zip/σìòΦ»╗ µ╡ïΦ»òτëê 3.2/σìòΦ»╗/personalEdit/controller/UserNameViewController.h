//
//  UserNameViewController.h
//  单读
//
//  Created by Macx on 16/2/13.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TitleView.h"

@interface UserNameViewController : UIViewController

@property (nonatomic, strong)TitleView *titleView;
@property (nonatomic, strong)UIButton *backBtn;

@end
