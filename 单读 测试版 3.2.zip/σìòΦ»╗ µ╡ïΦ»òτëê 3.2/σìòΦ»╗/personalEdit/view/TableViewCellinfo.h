//
//  TableViewCellinfo.h
//  单读
//
//  Created by Macx on 16/2/10.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCellinfo : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label1;

@end
