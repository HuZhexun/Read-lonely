//
//  TableViewCellinfo.m
//  单读
//
//  Created by Macx on 16/2/10.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "TableViewCellinfo.h"

@implementation TableViewCellinfo

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
