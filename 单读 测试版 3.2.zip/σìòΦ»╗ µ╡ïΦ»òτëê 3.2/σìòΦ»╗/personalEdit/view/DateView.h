//
//  DateView.h
//  单读
//
//  Created by Macx on 16/2/15.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DateView : UIView

@property (nonatomic, strong)UIButton *save;//保存的日期的方法
@property (nonatomic, strong)UIDatePicker *dateView;//日期视图

@end
